<head>
<link rel="icon" href="https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/S-Bahn-Logo_rot.svg/500px-S-Bahn-Logo_rot.svg.png">
    <title>Food5 - Trang quản lý</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="images/icons/favicon.ico">
    <link rel="apple-touch-icon" href="images/icons/favicon.png">
    <link rel="apple-touch-icon" sizes="72x72" href="images/icons/favicon-72x72.png">
    <link rel="apple-touch-icon" sizes="114x114" href="images/icons/favicon-114x114.png">
    <!--Loading bootstrap css-->
    <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,300,700">
    <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Oswald:400,700,300">
    <link type="text/css" rel="stylesheet" href="{{asset('public/backend/vendors/jquery-ui-1.10.4.custom/css/ui-lightness/jquery-ui-1.10.4.custom.min.css')}}">
    <link type="text/css" rel="stylesheet" href="{{asset('public/backend/vendors/font-awesome/css/font-awesome.min.css')}}">
    <link type="text/css" rel="stylesheet" href="{{asset('public/backend/vendors/bootstrap/css/bootstrap.min.css')}}">
    <!--LOADING STYLESHEET FOR PAGE-->
    <link type="text/css" rel="stylesheet" href="{{asset('public/backend/vendors/jplist/html/css/jplist-custom.css')}}">
    <!--Loading style vendors-->
    <link type="text/css" rel="stylesheet" href="{{asset('public/backend/vendors/animate.css/animate.css')}}">
    <link type="text/css" rel="stylesheet" href="{{asset('public/backend/vendors/jquery-pace/pace.css')}}">
    <link type="text/css" rel="stylesheet" href="{{asset('public/backend/vendors/iCheck/skins/all.css')}}">
    <link type="text/css" rel="stylesheet" href="{{asset('public/backend/vendors/jquery-news-ticker/jquery.news-ticker.css')}}">
    <!--Loading style-->
    <link type="text/css" rel="stylesheet" href="{{asset('public/backend/css/themes/style2/yellow-green.css')}}" id="theme-change" class="style-change color-change">
    <link type="text/css" rel="stylesheet" href="{{asset('public/backend/css/style-responsive.css')}}">
    <script type="text/javascript" src="{{asset('public/ckeditor/ckeditor.js')}}"></script>
</head>