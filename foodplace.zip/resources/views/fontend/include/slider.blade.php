<div class="b-slidercontainer">
      <div class="b-slider j-fullscreenslider ">
          <ul>
              <li data-transition="" data-slotamount="7">
                  <div class="tp-bannertimer"></div>
                  <img data-retina src="{{asset('public/fontend/img/slider/slider1.jpg')}}">
                  <div class="caption sfb"  data-x="30" data-y="bottom" data-speed="700" data-start="1700" data-easing="Power4.easeOut"><img data-retina src="img/slider/slider_shop_1-1.png"></div>
                  <div class="caption"  data-x="180" data-y="bottom" data-voffset="-1" data-speed="2100" data-start="3300" data-easing="easeOutBack"><img data-retina src="img/slider/slider_shop_1-2.png"></div>
                  <div class="caption lfr"  data-x="400"  data-y="100" data-speed="300" data-start="2000">
                      <div class="b-header-group f-header-group f-header-group--light">
                          <h1 class="f-primary-l">Sfood</h1>
                          <h2 class="f-primary-sb"> Ẩm thực ngon tại hà nội</h2>
                      </div>
                  </div>
                  <div class="caption lfb"  data-x="400" data-y="270" data-speed="300" data-start="2300">
                      <p class="f-primary-b f-uppercase f-slider-lg_text-medium c-white" >Khai trương website mới</p>
                  </div>
                  <div class="caption lfb"  data-x="400" data-y="300" data-speed="300" data-start="2600">
                      <p class="f-primary-b f-uppercase f-slider-lg_text-medium c-white" >Nhiều địa điểm hấp dẫn cho mùa hè</p>
                  </div>
                  <div class="caption"  data-x="400" data-y="340" data-speed="600" data-start="3000">
                      <p><a class="b-link f-link f-primary-b f-uppercase" href="#">Xem tiếp <span><i class="fa fa-chevron-right"></i></span></a></p>
                  </div>
              </li>
              <li data-transition="" data-slotamount="7">
                  <div class="tp-bannertimer"></div>
                  <img data-retina src="{{asset('public/fontend/img/slider/slider2.jpg')}}">
                  <div class="caption sfb"  data-x="30" data-y="bottom" data-speed="700" data-start="1700" data-easing="Power4.easeOut"><img data-retina src="img/slider/slider-shop-2-2.png"></div>
                  <div class="caption lfr"  data-x="400"  data-y="100" data-speed="300" data-start="2000">
                      <div class="b-header-group f-header-group f-header-group--light">
                           <h1 class="f-primary-l">Sfood</h1>
                          <h2 class="f-primary-sb"> Ẩm thực ngon tại hà nội</h2>
                      </div>
                  </div>
                  <div class="caption lfb"  data-x="400" data-y="270" data-speed="300" data-start="2300">
                       <p class="f-primary-b f-uppercase f-slider-lg_text-medium c-white" >Khai trương website mới</p>
                  </div>
                  <div class="caption lfb"  data-x="400" data-y="300" data-speed="300" data-start="2600">
                      <p class="f-primary-b f-uppercase f-slider-lg_text-medium c-white" >Nhiều địa điểm hấp dẫn cho mùa hè</p>
                  </div>
                  <div class="caption"  data-x="400" data-y="340" data-speed="600" data-start="3000">
                      <p><a class="b-link f-link f-primary-b f-uppercase" href="#">Xem tiếp <span><i class="fa fa-chevron-right"></i></span></a></p>
                  </div>
              </li>
              <li data-transition="" data-slotamount="7">
                  <div class="tp-bannertimer"></div>
                  <img data-retina src="{{asset('public/fontend/img/slider/slider3.jpg')}}">
                  <div class="caption sfb"  data-x="30" data-y="bottom" data-speed="700" data-start="1700" data-easing="Power4.easeOut"><img data-retina src="img/slider/slider-shop-3-3.png"></div>
                  <div class="caption lfr"  data-x="400"  data-y="100" data-speed="300" data-start="2000">
                      <div class="b-header-group f-header-group f-header-group--light">
                          <h1 class="f-primary-l">Sfood</h1>
                          <h2 class="f-primary-sb"> Ẩm thực ngon tại hà nội</h2>
                      </div>
                  </div>
                  <div class="caption lfb"  data-x="400" data-y="270" data-speed="300" data-start="2300">
                       <p class="f-primary-b f-uppercase f-slider-lg_text-medium c-white" >Khai trương website mới</p>
                  </div>
                  <div class="caption lfb"  data-x="400" data-y="300" data-speed="300" data-start="2600">
                      <p class="f-primary-b f-uppercase f-slider-lg_text-medium c-white" >Nhiều địa điểm hấp dẫn cho mùa hè</p>
                  </div>
                  <div class="caption"  data-x="400" data-y="340" data-speed="600" data-start="3000">
                      <p><a class="b-link f-link f-primary-b f-uppercase" href="#">Xem tiếp <span><i class="fa fa-chevron-right"></i></span></a></p>
                  </div>
              </li>
          </ul>
      </div>
  </div>