<?php namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;
use Auth;
class Foods extends Model {

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'foods';

	/**
	 * The attributes that are mass assignable.
	 *
	 * @var array
	 */
	protected $fillable = ['name', 'address', 'description', 'view', 'video', 'kind', 'image', 'price', 'total_wishtlist'];

	public function findAllFood()
    {
    	$food=DB::table('foods')->select('foods.*', 'users.name as name_user')
            ->join('user_foods','foods.id','=','user_foods.food_id')
            ->join('users','user_foods.user_id','=','users.id')
            // ->join('categories_products','products.id','=','categories_products.product_id')
            // ->join('categories', 'categories_products.categories_id','=','categories.id')
            ->groupby('foods.id')
            ->orderby('foods.created_at', 'desc');
            return $food;
    }

    public function findFoodNew($soluong)
    {
    	$place=DB::table('foods')->select('foods.*', 'users.name as name_user')
            ->join('user_foods','foods.id','=','user_foods.food_id')
            ->join('users','user_foods.user_id','=','users.id')
            ->groupby('foods.id')
            ->orderby('foods.created_at', 'desc')->take($soluong);
            return $place;
    }
     public function findFoodUser()
    {
    	$id=Auth::user()->id;
    	$food=DB::table('foods')->select('foods.*', 'users.name as name_user')
            ->join('user_foods','foods.id','=','user_foods.food_id')
            ->join('users','user_foods.user_id','=','users.id')
            ->where('user_foods.user_id','=', $id)
            ->groupby('foods.id');
        return $food;
    }
}
